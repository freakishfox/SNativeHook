package android.icarus;

/** Marker interface for Icarus modules. Cannot be implemented directly. */
/* package */ interface IIcarusMod {}
