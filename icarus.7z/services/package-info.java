/**
 * Contains file access services provided by the Icarus framework.
 */
package android.icarus.services;
