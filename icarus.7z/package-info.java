/**
 * Contains the main classes of the Icarus framework.
 */
package android.icarus;
