/**
 * Contains the base classes for callbacks.
 *
 * <p>For historical reasons, {link android.icarus.XC_MethodHook} and
 * {link android.icarus.XC_MethodReplacement} are directly in the
 * {@code android.icarus} package.
 */
package android.icarus.callbacks;

